const Attendance = require('../Model/Attendencenmodel');

exports.markAttendance = async (req, res) => {
    try {
        const attendance = new Attendance({
            userId: req.user.userId,
            selfie: req.file.path,
        });
        await attendance.save();
        res.status(201).json({ message: 'Attendance marked successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAttendanceHistory = async (req, res) => {
    try {
        const records = await Attendance.find({ userId: req.user.userId });
        res.json(records);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
