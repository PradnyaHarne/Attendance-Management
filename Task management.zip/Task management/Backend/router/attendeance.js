const express = require('express');
const multer = require('multer');
const { authenticate } = require('../middleware/authenticate');
const attendanceController = require('../controllers/attendanceController');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/mark', authenticate, upload.single('selfie'), attendanceController.markAttendance);

router.get('/history', authenticate, attendanceController.getAttendanceHistory);

module.exports = router;
