const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
    name: {
        type:String,
        required:true
},
    email: { 
        type: String,
         unique: true
         },
    password: String, 
    role: { 
        type: String, 
        enum: ['Student', 'Teacher', 'Admin'] 
    },
    profilePicture: String,
    isActive: { type: Boolean, default: true },
},TimeStamp);
module.exports = mongoose.model('User', userSchema);
