const attendanceSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    date: { type: Date, default: Date.now },
    selfieUrl: String,
});
module.exports = mongoose.model('Attendance', attendanceSchema);
